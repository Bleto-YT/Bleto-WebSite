UPDATE chats
SET chat = ?
WHERE user_id = ?